# Código reutilizable
